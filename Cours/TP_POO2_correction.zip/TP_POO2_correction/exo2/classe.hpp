#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Etudiant{
public :

    // Constructeur
    Etudiant(string n, string p, unsigned int id, int nbnote=5):nom(n), prenom(p), identifiant(id), tailleMaxTableau(nbnote)
    {
       this->notes = new float[tailleMaxTableau]; // creation du tableau dynamique avec une taille tailleMaxTableau
        nbreNotes = 0; // nous avons besoin d un attribut supplementaire nbreNotes qui sera increment� a chaque nouvelle note entr�e dans le tableau
    }

    // Constructeur de copie
    Etudiant(const Etudiant& eleve):nom(eleve.nom), prenom(eleve.prenom), identifiant(eleve.identifiant), nbreNotes(eleve.nbreNotes), tailleMaxTableau(eleve.tailleMaxTableau)
    {
        this->notes = new float[tailleMaxTableau]; // creation du tableau dynamique avec une taille identique a celle de l'instance eleve pour la nouvelle instance
        for(int i=0; i<nbreNotes;i++)        // remplissage du tableau dynamique avec les notes de l'instance eleve (ne pas oublier)
        {
            this->notes[i] = eleve.notes[i];
        }

    }
    /* Surchage externe de l operateur << permettant d acceder au elements public et priv� de la classe Etudiant
    Not� l'utilisation du mot cl� friend (ami)*/
    friend ostream& operator<<(ostream& sortie, Etudiant& eleve);

    void ajouterNote(float note) {
        if (nbreNotes < tailleMaxTableau) {
            this->notes[nbreNotes] = note;
            this->nbreNotes ++;
        }
        else
        {
            cout << "Nombres de notes au maximum" << endl;
        }
    }

    // les accesseurs (get)
    string getNom() {return nom;}
    string getPrenom() {return prenom;}
    int getNombreNotes(){return nbreNotes;}
    unsigned int getId() {return identifiant;}

    // les mutateurs (set)
    void setNom(string n) {nom = n;}
    void setPrenom(string p) {prenom = p;}
    void setId(unsigned int id) {identifiant = id;}

    ~Etudiant()
    {
        delete notes; // a la suppression de l'instance, on detruit le tableau notes allou� dynamiquement

    }

    float * notes; // pointeur sur un float pour pouvoir construire le tableau dynamique de notes

private :

    string nom, prenom;
    unsigned int identifiant;

    int tailleMaxTableau;
    int nbreNotes;
};


// Definition de la fonction de surchage externe de l operateur << permettant d acceder au elements public de la classe Etudiant
ostream& operator<<(ostream& sortie, Etudiant& eleve)
{
            sortie << '(' <<  eleve.getNom() <<' ' << eleve.getPrenom() << ' ' << eleve.getId() << ' ' << "Notes : " ;
            for(int i=0; i<eleve.getNombreNotes();i++)        // remplissage du tableau dynamique avec les notes de l'instance eleve (ne pas oublier)
            {
                 sortie << eleve.notes[i] << ' ';
            }
            sortie << ')' << endl;
            return sortie;

}
