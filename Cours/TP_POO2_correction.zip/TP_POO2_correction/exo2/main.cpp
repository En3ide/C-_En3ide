#include <iostream>
#include "classe.hpp"

using namespace std;

int main()
{

    // Creation d'un etudiant eleve1
    Etudiant eleve1("PROVOLO", "alain", 123456, 8);

    eleve1.ajouterNote(1);
    eleve1.ajouterNote(2);


    // Affichage  des notes de eleve1
    cout <<eleve1.getNom() << endl;
    for(int i=0; i<eleve1.getNombreNotes(); i++) {
        cout << eleve1.notes[i] << endl;
    }


    // Cr�ation d'un etudiant par copie eleve2 a partir de eleve1
    Etudiant eleve2(eleve1); // appel du constructeur de copie
    cout << eleve2.getPrenom() << endl;

    // Affichage des notes de eleve2
   for(int i=0; i<eleve2.getNombreNotes(); i++) {
        cout << eleve2.notes[i] << endl;
    }

    // Cr�ation d'un etudiant dynamiquement par copie a partir de eleve2
    Etudiant * ptrEleve;
    ptrEleve = new Etudiant(eleve2); // appel du constructeur de copie
    cout << ptrEleve->getId();

    // Affichage des notes de ptrEleve
   for(int i=0; i<ptrEleve->getNombreNotes(); i++) {
        cout << ptrEleve->notes[i] << endl;
    }
    delete ptrEleve;


    cout << eleve1;
    cout << eleve2;

    return 0;
}
