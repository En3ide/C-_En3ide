#include <iostream>

using namespace std;

class Rectangle {
public :
    // Constructeur
    Rectangle() : hauteur(0.0), largeur(0.0)
    {}

    double perimetre() {
        return (2*hauteur+2*largeur);
    }

    double surface() {
        return hauteur*largeur;
    }

    void affiche() {
        cout << "Rectangle L:"<< largeur << " H:" << hauteur << endl;
    }

    double getHauteur() {return hauteur;}
    double getLargeur() {return largeur;}

    void setHauteur(double h) {hauteur = h;}
    void setLargeur(double l) {largeur = l;}

private :
    double hauteur;
    double largeur;

};
