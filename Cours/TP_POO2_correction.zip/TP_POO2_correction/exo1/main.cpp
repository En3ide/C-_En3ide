#include <iostream>
#include "classe.hpp"

using namespace std;

int main()
{
    double recH, recL;
    cout << "Largeur : ";
    cin >> recL;
    cout << "Hauteur : ";
    cin >> recH;

    const Rectangle rect;

    rect.setHauteur(recH);
    rect.setLargeur(recL);
    rect.affiche();

    cout << "Perimetre = " << rect.perimetre() << endl;
    cout << "Surface = " << rect.surface() << endl;


    return 0;
}
