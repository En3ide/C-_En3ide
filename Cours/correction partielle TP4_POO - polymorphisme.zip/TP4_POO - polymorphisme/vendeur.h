#ifndef VENDEUR_H
#define VENDEUR_H

#include "commercial.h"


class vendeur : public commercial
{
    public:
        vendeur(string name, string surname, int age, string rol);
        virtual ~vendeur();
        float calculerSalaire();

    protected:

    private:
};

#endif // VENDEUR_H
