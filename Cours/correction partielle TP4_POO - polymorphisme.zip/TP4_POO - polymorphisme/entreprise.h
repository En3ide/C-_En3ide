#ifndef ENTREPRISE_H
#define ENTREPRISE_H

#include <iostream>
#include <string>

using namespace std;

#include "vendeur.h"
#include "representant.h"
#include <vector>


class entreprise
{
    public:
        entreprise(string name);
        virtual ~entreprise();

        string Getnom() { return nom; }
        void afficherListeEmployes();
        void ajouterVendeur(string name, string surname, int age);
        void ajouterRepresentant(string name, string surname, int age);
        void ajouterPrimesVendeur(string name, int nbrePrimes);
        void ajouterPrimesRepresentant(string name, int nbrePrimes);
        void ajouterNbreDeplacementRepresentant(string name, int nbreDeplacement);
        void calculerSalaire();
        void afficherSalaireEmployes();

    protected:

    private:
        string nom;
        vector<employe *> employes;

};

#endif // ENTREPRISE_H
