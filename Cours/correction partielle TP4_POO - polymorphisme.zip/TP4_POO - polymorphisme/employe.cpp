#include "employe.h"

employe::employe(string name, string surname, int age, string rol):nom(name),prenom(surname),age(age),role(rol)
{
    //ctor
}

employe::~employe()
{
    //dtor
}


float employe::calculerSalaire()
{

}

void employe::affiche()
{
        cout << nom << " "  << age << "ans" ;
}

 void employe::ajouterPrimes(int prim)
 {

 }

void employe::ajouterNbreDeplacement(int nbre)
{

}
