#ifndef EMPLOYE_H
#define EMPLOYE_H

#include <iostream>
#include <string>
using namespace std;


class employe
{
    public:
        employe(string name, string surname, int age, string rol);
        virtual ~employe();

        string Getnom() { return nom; }
        string Getprenom() { return prenom; }
        string Getrole(){ return role;}
        int Getage() { return age; }
        float getSalaire(){return salaire;}


        virtual float calculerSalaire();
        virtual void ajouterPrimes(int prim);
        virtual  void ajouterNbreDeplacement(int nbre);
        void affiche();

    protected:
        string nom;
        string prenom;
        string role;
        int age;
        float salaire;


    private:

};

#endif // EMPLOYE_H
