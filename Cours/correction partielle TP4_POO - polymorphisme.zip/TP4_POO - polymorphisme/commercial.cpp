#include "commercial.h"

commercial::commercial(string name, string surname, int age, string rol):employe(name,surname,age,rol),salaireBase(50),Tauxprime(0)
{
    //ctor
}

commercial::~commercial()
{
    //dtor
}
