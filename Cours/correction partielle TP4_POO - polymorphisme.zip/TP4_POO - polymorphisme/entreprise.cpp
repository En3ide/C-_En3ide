#include "entreprise.h"

entreprise::entreprise(string name):nom(name)
{
    //ctor
}

entreprise::~entreprise()
{
    //dtor

    for(int i=0; i< employes.size();i++)
    {
        delete employes[i];
    }


}

void entreprise::afficherListeEmployes()
{
    cout << "l entreprise " << this->nom  << " se compose de  " << employes.size() << endl;
    cout << '\t' << "Nos employes :" << endl;

    for(int i=0; i< employes.size();i++)
    {

         cout  << '\t'<< '\t'<< '\t' << employes[i]->Getnom()  << " :" << employes[i]->Getrole() << endl;
    }



}

void entreprise::ajouterVendeur(string name, string surname, int age)
{
   vendeur * ptr = new vendeur(name,surname,age,"vendeur");
   employes.push_back(ptr);
}


void entreprise::ajouterRepresentant(string name, string surname, int age)
{
    representant * ptr = new representant(name,surname,age,"representant");
    employes.push_back(ptr);
}


void entreprise::ajouterPrimesVendeur(string name, int nbrePrimes)
{
  // recherche du vendeur et ajout du nombre de primes
   for(int i=0; i< employes.size();i++)
    {
         if(employes[i]->Getnom() == name  && employes[i]->Getrole() == "vendeur")
         {
             employes[i]->ajouterPrimes(nbrePrimes);
         }
    }


}

void entreprise::ajouterPrimesRepresentant(string name, int nbrePrimes)
{
    // recherche du representant et ajout du nombre de primes

     for(int i=0; i< employes.size();i++)
    {
        if(employes[i]->Getnom() == name  && employes[i]->Getrole() == "representant")
             {
                 employes[i]->ajouterPrimes(nbrePrimes);
             }
    }

}


 void entreprise::ajouterNbreDeplacementRepresentant(string name, int nbreDeplacement)
 {
      // recherche du representant et ajout du nombre de primes de deplacement

     for(int i=0; i< employes.size();i++)
    {
        if(employes[i]->Getnom() == name  && employes[i]->Getrole() == "representant")
             {
                 employes[i]->ajouterNbreDeplacement(nbreDeplacement);
             }
    }
 }





void entreprise::calculerSalaire()
{
    for(int i=0; i< employes.size();i++)
    {
       employes[i]-> calculerSalaire();
    }

}

void entreprise::afficherSalaireEmployes()
{
    cout << "Salaire des employes :" << endl;
     cout << '\t' << "Salaire des employes :" << endl;

    for(int i=0; i< employes.size();i++)
    {
         cout  << '\t'<< '\t'<< '\t' << employes[i]->Getnom() << "(" << employes[i]->Getrole()<< ") " << ": " << employes[i]->getSalaire() << " iris" << endl;
    }



}
