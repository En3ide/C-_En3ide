#include "representant.h"

representant::representant(string name, string surname, int age, string rol):commercial(name,surname,age,rol),nbrePrimesDeplacement(0)
{
    //ctor
    Tauxprime=5;
}

representant::~representant()
{
    //dtor
}

 void representant::ajouterNbreDeplacement(int nbre)
 {
     nbrePrimesDeplacement = nbre;
 }

float representant::calculerSalaire()
{
    salaire = salaireBase + Tauxprime * GetPrime() + 1 * nbrePrimesDeplacement;
    return salaire;
}



