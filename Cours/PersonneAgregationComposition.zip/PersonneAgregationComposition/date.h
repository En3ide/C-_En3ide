#ifndef DATE_H
#define DATE_H


class Date
{
    public:
        Date();
        Date(int, int, int);
        virtual ~Date();

         int GetnumJour() { return numJour; }
        void SetnumJour( int val) { numJour = val; }
         int GetnumMois() { return numMois; }
        void SetnumMois( int val) { numMois = val; }
         int Getannee() { return annee; }
        void Setannee( int val) { annee = val; }

    private:
         int numJour;
         int numMois;
         int annee;
};

#endif // DATE_H
