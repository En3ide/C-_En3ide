#include "date.h"

Date::Date()
{
    //ctor
}

Date::Date(int j, int m , int an): numJour(j),numMois(m),annee(an)
{

}

Date::~Date()
{
    //dtor
}
