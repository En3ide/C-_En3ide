#include "personne.h"

Personne::Personne(string prenom, string nom):prenom(prenom), nom(nom)
{
    //ctor
}

Personne::Personne(string prenom, string nom, int j, int m, int a):prenom(prenom), nom(nom), dateNaissance(j,m,a),conjoint(0)
{
    //ctor
}

Personne::~Personne()
{
    //dtor
}

string Personne::getNom()
{
   return nom;
}

string Personne::getPrenom()
{
     return prenom;
}

void Personne::setNom(string name)
{
    nom = name;
}

int Personne::getAge()
{
     time_t now = time(0);

   // convert now to string form
   tm *ltm = localtime(&now);
   return  1900 +ltm->tm_year  - dateNaissance.Getannee();

}

void Personne::epouse( Personne * p)
{
        conjoint = p; // le pointeur conjoint pointe sur l'adresse de l'objet avec qui je suis marie
        p->conjoint = this; // le pointeur conjoint de l'objet avec qui je suis marie pointe sur moi (this)
                            // agregation bidirectionnelle
}

void Personne::seSepare()
{
    this->conjoint->conjoint = 0;   // le pointeur conjoint de l'objet avec qui j'etais marie pointe sur rien (null)
    conjoint = 0;  // mon pointeur coinjoint pointe sur rien (null)
}

void Personne::changerConjoint(Personne * p)
{
    conjoint = p;   // idem que la m�thode epouse()
    p->conjoint = this;

}

string Personne::getEtat()
{
    string etat;
   if(conjoint == 0)
   {
       etat = "celibataire";
   }
   else
   {
       etat = "marie(e) a " + conjoint->getNom() + " " + conjoint->getPrenom();

   }
   return etat;

}

