#ifndef PERSONNE_H
#define PERSONNE_H

#include <iostream>
#include <string>

#include "date.h"
#include <ctime>

using namespace std;

class Personne
{
    public:
        Personne(string prenom, string nom);
        Personne(string prenom, string nom, int j , int m, int annee);
        ~Personne();

        string getNom();
        string getPrenom();
        void setNom(string name);
        int getAge();
        void epouse( Personne *);
        void seSepare();
        void changerConjoint(Personne *);
        string getEtat();

    private:
        string nom;
        string prenom;
        Date dateNaissance; // composition
        Personne * conjoint; // pointeur pour agregation avec le conjoint
};

#endif // PERSONNE_H
