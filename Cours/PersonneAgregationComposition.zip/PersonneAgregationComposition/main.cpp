#include <iostream>

#include "personne.h"



using namespace std;


/*void Marier( Personne a, Personne b)
{
        a.epouse(&b);
}*/

void Marier( Personne &a, Personne &b)
{
    a.epouse(&b);
}


    int main()
    {
        cout << "Agregation et Composition!" << endl;

        Personne phil("Philippe", "DURANT", 10,2,1978 );
        Personne laure("Laure", "BLANQUART", 10,8,1977 );
        Personne autre("charmante", "Inconnu", 12,7,1977 );
        Personne  *louis;
        louis = new Personne("Louis", "BROCHE",1,1,2000);


        cout << phil.getPrenom() << " " << phil.getNom() << " est " << phil.getEtat() << endl;
        cout << laure.getPrenom() << " " << laure.getNom() << " est " << laure.getEtat() << endl;

        cout << "Mariage !!" << endl;
        Marier(phil,laure);

        cout << phil.getPrenom() << " " << phil.getNom() << " est " << phil.getEtat() << endl;
        cout << laure.getPrenom() << " " << laure.getNom() << " est " << laure.getEtat() << endl;

        cout << "Separation !!" << endl;
        phil.seSepare();

        cout << phil.getPrenom() << " " << phil.getNom() << " est " << phil.getEtat() << endl;
        cout << laure.getPrenom() << " " << laure.getNom() << " est " << laure.getEtat() << endl;

        cout << "Mariage !!" << endl;
        Marier(autre,*louis);
        cout << louis->getPrenom() << " " << louis->getNom() << " est " << louis->getEtat() << endl;
        cout << autre.getPrenom() << " " << autre.getNom() << " est " << autre.getEtat() << endl;


        cout << "Separation !!" << endl;
        louis->seSepare();

        cout << louis->getPrenom() << " " << louis->getNom() << " est " << louis->getEtat() << endl;
        cout << autre.getPrenom() << " " << autre.getNom() << " est " << autre.getEtat() << endl;

        // Changement de conjoint
       cout << "Louis  : Changement de conjoint  avec autre !!" << endl;
        louis->changerConjoint(&laure);

        cout << louis->getPrenom() << " " << louis->getNom() << " est " << louis->getEtat() << endl;
        cout << laure.getPrenom() << " " << laure.getNom() << " est " << laure.getEtat() << endl;
        cout << autre.getPrenom() << " " << autre.getNom() << " est " << autre.getEtat() << endl;


        return 0;
    }



/*    phil= *louis;
    //   L'affectation standard  a pour seul effet de dupliquer les donn�es membres, string en particulier, mais pas le tableau de caract�res associ�
    //   L'op�rateur d'affectation standard doit donc �tre surcharg�, pour dupliquer aussi les zones point�es si l on utilise des tableaux
    cout << phil.getPrenom() << " " << phil.getNom() << " est " << phil.getEtat() << endl;
    delete louis;
    cout << phil.getPrenom() << " " << phil.getNom() << " est " << phil.getEtat() << endl;
*/

/*

    int main(void)
    {
       Personne phil( "Philippe", "Durant", 10, 2, 1978 );
       Personne elo( "�lodie", "Dupond", 2, 5, 1979 );
       Marier(phil,elo);
       return 0;

    }

       // Nouvelle personne : Philippe Durant, n� le 10/01/1979
        Personne phil("Philippe Durant", 10, 1, 1979);
        int age = phil.getAge(); // r�cup�re l��ge de philippe
        cout << phil.getNom() << " a " << age << " ans. " << endl;
        return 0;

         Personne phil("Philippe","Durand");
        string nom = phil.getNom();
        cout << "Saisissez un nouveau nom pour " << nom << " : " ;
        string nouveauNom;
        cin >> nouveauNom;
        phil.setNom(nouveauNom);
        */
