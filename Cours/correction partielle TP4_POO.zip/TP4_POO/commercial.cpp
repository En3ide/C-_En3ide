#include "commercial.h"

commercial::commercial(string name, string surname, int age):employe(name,surname,age),salaireBase(50),Tauxprime(0)
{
    //ctor
}

commercial::~commercial()
{
    //dtor
}
