#ifndef REPRESENTANT_H
#define REPRESENTANT_H

#include "commercial.h"


class representant : public commercial
{
    public:
        representant(string name, string surname, int age);
        virtual ~representant();
        float  calculerSalaire();
        void ajouterNbreDeplacement(int nbre);

    protected:

    private:
        int nbrePrimesDeplacement;

};

#endif // REPRESENTANT_H
