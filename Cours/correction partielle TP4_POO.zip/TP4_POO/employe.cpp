#include "employe.h"

employe::employe(string name, string surname, int age):nom(name),prenom(surname),age(age)
{
    //ctor
}

employe::~employe()
{
    //dtor
}


float employe::calculerSalaire()
{

}

void employe::affiche()
{
        cout << nom << " "  << age << "ans" ;
}
