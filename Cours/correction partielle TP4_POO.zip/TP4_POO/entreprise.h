#ifndef ENTREPRISE_H
#define ENTREPRISE_H

#include <iostream>
#include <string>

using namespace std;

#include "vendeur.h"
#include "representant.h"
#include <vector>


class entreprise
{
    public:
        entreprise(string name);
        virtual ~entreprise();

        string Getnom() { return nom; }
        void afficherListeEmployes();
        void ajouterVendeur(string name, string surname, int age);
        void ajouterRepresentant(string name, string surname, int age);
        void ajouterPrimesVendeur(string name, int nbrePrimes);
        void ajouterPrimesRepresentant(string name, int nbrePrimes);
        void ajouterNbreDeplacementRepresentant(string name, int nbreDeplacement);
        void calculerSalaireVendeurs();
        void calculerSalaireRepresentants();
        void calculerSalaireRepresentants();

    protected:

    private:
        string nom;
        vector<vendeur *> vendeurs;
        vector<representant *> representants;
};

#endif // ENTREPRISE_H
