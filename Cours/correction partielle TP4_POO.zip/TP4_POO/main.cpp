#include <iostream>

#include "entreprise.h"
#include "vendeur.h"
#include "representant.h"

using namespace std;

int main()
{
    cout << "TP POO 4" << endl;

    entreprise uneEntreprise("PromoIRIS");

    // ajout des vendeurs
    uneEntreprise.ajouterVendeur("Paul"," ", 45);
    uneEntreprise.ajouterVendeur("Pierre"," ", 30);
    uneEntreprise.ajouterVendeur("Jacques"," ", 25);

    // ajout des primes aux vendeurs
    uneEntreprise.ajouterPrimesVendeur("Paul",10);
    uneEntreprise.ajouterPrimesVendeur("Pierre",5);
    uneEntreprise.ajouterPrimesVendeur("Jacques",1);

    // ajout des representants
    uneEntreprise.ajouterRepresentant("Giselle", "" , 28);
    uneEntreprise.ajouterRepresentant("George", "" , 52);

    uneEntreprise.afficherListeEmployes();

    // ajout des primes aux representants
    uneEntreprise.ajouterPrimesRepresentant("Giselle",3);
    uneEntreprise.ajouterPrimesRepresentant("George",2);

    // ajout des deplacements aux representants

    uneEntreprise.ajouterNbreDeplacementRepresentant("Giselle",10);
    uneEntreprise.ajouterNbreDeplacementRepresentant("George",8);

    // calcul des salaires
    uneEntreprise.calculerSalaireVendeurs();
    uneEntreprise.calculerSalaireRepresentants();

    // affichage des salaires
    uneEntreprise.afficherSalaireEmployes();





    return 0;
}
