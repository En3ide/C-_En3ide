#include "entreprise.h"

entreprise::entreprise(string name):nom(name)
{
    //ctor
}

entreprise::~entreprise()
{
    //dtor

    for(int i=0; i< vendeurs.size();i++)
    {
        delete vendeurs[i];
    }

    for(int i=0; i< representants.size();i++)
    {
        delete representants[i];
    }
}

void entreprise::afficherListeEmployes()
{
    cout << "l entreprise " << this->nom  << " se compose de  " << representants.size() << " representants et de " << vendeurs.size()  << " vendeurs" << endl;
    cout << '\t' << "Nos representants :" << endl;

    for(int i=0; i< representants.size();i++)
    {
         cout  << '\t'<< '\t'<< '\t' << representants[i]->Getnom() << endl;
    }

     cout << '\t' << "Nos vendeurs :" << endl;

    for(int i=0; i< vendeurs.size();i++)
    {
         cout  << '\t'<< '\t'<< '\t' << vendeurs[i]->Getnom() << endl;
    }

}

void entreprise::ajouterVendeur(string name, string surname, int age)
{
   vendeur * ptr = new vendeur(name,surname,age);
   vendeurs.push_back(ptr);
}


void entreprise::ajouterRepresentant(string name, string surname, int age)
{
    representant * ptr = new representant(name,surname,age);
    representants.push_back(ptr);
}


void entreprise::ajouterPrimesVendeur(string name, int nbrePrimes)
{
  // recherche du vendeur et ajout du nombre de primes
   for(int i=0; i< vendeurs.size();i++)
    {
         if(vendeurs[i]->Getnom() == name)
         {
             vendeurs[i]->ajouterPrimes(nbrePrimes);
         }
    }


}

void entreprise::ajouterPrimesRepresentant(string name, int nbrePrimes)
{
    // recherche du representant et ajout du nombre de primes

     for(int i=0; i< representants.size();i++)
    {
        if(representants[i]->Getnom() == name)
             {
                 representants[i]->ajouterPrimes(nbrePrimes);
             }
    }

}


 void entreprise::ajouterNbreDeplacementRepresentant(string name, int nbreDeplacement)
 {
      // recherche du representant et ajout du nombre de primes de deplacement

     for(int i=0; i< representants.size();i++)
    {
        if(representants[i]->Getnom() == name)
             {
                 representants[i]->ajouterNbreDeplacement(nbreDeplacement);
             }
    }
 }

void entreprise::calculerSalaireVendeurs()
{
    for(int i=0; i< vendeurs.size();i++)
    {
       vendeurs[i]-> calculerSalaire();
    }

}

void entreprise::calculerSalaireRepresentants()
{
    for(int i=0; i< representants.size();i++)
    {
       representants[i]-> calculerSalaire();
    }

}

void entreprise::afficherSalaireEmployes()
{
    cout << "Salaire des employes :" << endl;
     cout << '\t' << "Salaire des representants :" << endl;

    for(int i=0; i< representants.size();i++)
    {
         cout  << '\t'<< '\t'<< '\t' << representants[i]->Getnom()  << ": " << representants[i]->getSalaire() << " iris" << endl;
    }

     cout << '\t' << "Salaire des vendeurs :" << endl;

    for(int i=0; i< vendeurs.size();i++)
    {
         cout  << '\t'<< '\t'<< '\t' << vendeurs[i]->Getnom() << ": " << vendeurs[i]->getSalaire() << " iris" <<endl;
    }

}
