#include "representant.h"

representant::representant(string name, string surname, int age):commercial(name,surname,age),nbrePrimesDeplacement(0)
{
    //ctor
    Tauxprime=5;
}

representant::~representant()
{
    //dtor
}

 void representant::ajouterNbreDeplacement(int nbre)
 {
     nbrePrimesDeplacement = nbre;
 }

float representant::calculerSalaire()
{
    salaire = salaireBase + Tauxprime * GetPrime() + 1 * nbrePrimesDeplacement;
    return salaire;
}



