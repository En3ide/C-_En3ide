#include "vendeur.h"

vendeur::vendeur(string name, string surname, int age):commercial(name,surname,age)
{
    //ctor
    Tauxprime=2;
}

vendeur::~vendeur()
{
    //dtor
}

float vendeur::calculerSalaire()
{
      salaire =salaireBase + Tauxprime * GetPrime();
      return salaire;
}
