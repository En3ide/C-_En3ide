#ifndef COMMERCIAL_H
#define COMMERCIAL_H

#include "employe.h"


class commercial : public employe
{
    public:
        commercial(string name, string surname, int age);
        virtual ~commercial();

        float GetsalaireBase() { return salaireBase; }
        float GetTauxprime() { return Tauxprime; }
        float GetPrime(){return primes;}
        void SetTauxprime(float val) { Tauxprime = val; }
        void ajouterPrimes(int prim){primes = prim;}


    protected:
        float salaireBase;
        float Tauxprime;

    private:
        int primes;
};

#endif // COMMERCIAL_H
