#ifndef EMPLOYE_H
#define EMPLOYE_H

#include <iostream>
#include <string>
using namespace std;


class employe
{
    public:
        employe(string name, string surname, int age);
        virtual ~employe();

        string Getnom() { return nom; }
        string Getprenom() { return prenom; }
        int Getage() { return age; }
        float getSalaire(){return salaire;}


        float calculerSalaire();
        void affiche();

    protected:
        string nom;
        string prenom;
        int age;
        float salaire;

    private:

};

#endif // EMPLOYE_H
